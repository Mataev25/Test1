#include <windows.h>
#include <fstream>
#include <iostream>
#include <vector>
#include <string>

class BmpApp {
private:
#pragma pack(push, 1)
	struct BMPHeader {
		WORD bfType;
		DWORD bfSize;
		WORD bfReserve1 = 0;
		WORD bfReserve2 = 0;
		DWORD bf0ffBits;
		DWORD biSize;
		LONG biWidth;
		LONG biHeight;
		WORD biPlanes;
		WORD biBitPerPixel;
		DWORD biCompression;
		DWORD biSizePixel;
	};
#pragma pack(pop)

	BMPHeader header;
	std::vector<BYTE> imageData;
	int rowSize;
	int width;
	int height;
	void read_file(std::ifstream& file);
	void draw_line(int x1, int y1, int x2, int y2, bool convert_color);
	bool is_white_or_black();
	void get_pixel(int x, int y, BYTE& r, BYTE& g, BYTE& b)const;
	
public:
	bool loading(const std::string filename);
	void print() const;
	void draw();
	bool save(const std::string& failename);
};
void BmpApp::read_file(std::ifstream& file) {
	file.seekg(header.bf0ffBits, std::ios::beg);
	imageData.resize(header.biSizePixel);
	file.read(reinterpret_cast<char*>(imageData.data()), header.biSizePixel);
}
bool BmpApp::loading(const std::string filename) {
	std::ifstream file(filename, std::ios::binary);
	if (!file) return false;
	file.read(reinterpret_cast<char*>(&header), sizeof(header));
	if (header.bfType != 0x4D42) { 
		file.close();
		return false; 
	}
	if (header.biBitPerPixel != 24 && header.biBitPerPixel != 32) return false;
	width = header.biWidth;
	height = abs(header.biHeight);
	rowSize = ((width * 3 + 3) & ~3);
	read_file(file);
	file.close();
	return true;
}
void BmpApp::print()const {
	for (int y = height - 1; y >= 0; y--) {
		for (int x = 0; x < width; x++) {
			BYTE r, g, b;
			get_pixel(x, y, r, g, b);
			std::cout << (r == 255 && g == 255 && b == 255 ? '#' : '?');
		}
		std::cout << std::endl;
	}
	std::cout << "\n";
}
void BmpApp::draw_line(int x1, int y1, int x2, int y2, bool convert_color) {
	int dx = abs(x2 - x1);
	int dy = abs(y2 - y1);
	int sx = (x1 < x2) ? 1 : -1;
	int sy = (y1 < y2) ? 1 : -1;
	int err = dx - dy;

	BYTE color = convert_color ? 0 : 255;

	while (true) {
		if (x1 >= 0 && x1 < width && y1 >= 0 && y1 < height) {
			int offset = y1 * rowSize + x1 * 3;
			imageData[offset] = color;
			imageData[offset + 1] = color;
			imageData[offset + 2] = color;
		}
		if (x1 == x2 && y1 == y2) break;
		int e2 = 2 * err;
		if (e2 > -dy) {
			e2 -= dy;
			x1 += sx;
		}
		if (e2 < dx) {
			e2 += dx;
			y1 += sy;
		}
	}
}
bool BmpApp::is_white_or_black() {
	BYTE r, g, b;
	get_pixel(width / 2, height / 2, r, g, b);
	bool convert_color=(r == 255 && g == 255 && b == 255);
	return convert_color;
}
void BmpApp::draw() {
	bool conv_col = is_white_or_black();
	draw_line(0, 0, width - 1, height - 1, conv_col);
	draw_line(width - 1, 0, 0, height - 1, conv_col);
}
bool BmpApp::save(const std::string& failename) {
	std::ofstream file(failename, std::ios::binary);
	if (!file) return false;
	file.write(reinterpret_cast<char*>(&header), sizeof(header));
	file.seekp(header.bf0ffBits, std::ios::beg);
	file.write(reinterpret_cast<char*>(imageData.data()), imageData.size());
	file.close();
	return true;
}
void BmpApp::get_pixel(int x, int y, BYTE& r, BYTE& g, BYTE& b)const {
	int PixelPos = y * rowSize + x * 3;
	b = imageData[PixelPos];
	g = imageData[PixelPos + 1];
	r = imageData[PixelPos + 2];
}

int main() {
	setlocale(LC_ALL, "ru");
	BmpApp app;

	std::string filename_in;
	std::cout << "Введите имя входного файла\n";
	std::cin >> filename_in;

	if (!app.loading(filename_in)) {
		MessageBoxA(NULL, "Ошибка загрузки файла!", "Ошибка", MB_ICONERROR);
	}
	std::cout << "Исходное изображение\n\n";
	app.print();

	std::cout << "Рисуем крест\n";
	app.draw();

	std::cout << "Изображение с крестом\n\n";
	app.print();
	
	std::string filename_out;
	std::cout << "Введите имя сохраняемого файла\n";
	std::cin >> filename_out;

	if (!app.save(filename_out)) {
		MessageBoxA(NULL, "Ошибка сохранения файла!", "Ошибка", MB_ICONERROR);
	}
}
